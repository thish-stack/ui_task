import 'package:flutter/material.dart';

class AppTheme {
  static final Color background = Color(0xFF0E0E0E);
  static final Color cardColor = Color(0xFF1E1E1E);
  static final TextStyle titleStyle =
      TextStyle(fontSize: 18, fontWeight: FontWeight.bold);
}
