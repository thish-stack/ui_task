import 'package:flutter/material.dart';

class SearchFilterRow extends StatelessWidget {
  const SearchFilterRow({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          IconButton(
            icon: const Icon(Icons.search, size: 28),
            onPressed: () {},
          ),
          Row(
            children: [
              IconButton(
                  icon: const Icon(Icons.more_horiz, size: 28),
                  onPressed: () {}),
              IconButton(
                  icon: const Icon(Icons.calendar_today, size: 28),
                  onPressed: () {}),
              IconButton(
                  icon: const Icon(Icons.folder, size: 28),
                  onPressed: () {}),
              Container(
                decoration: const BoxDecoration(
                  color: Color(0xFFE2D291),
                  shape: BoxShape.circle,
                ),
                child: IconButton(
                  icon: const Icon(
                    Icons.add,
                    size: 28,
                    color: Colors.black,
                  ),
                  padding: EdgeInsets.zero,
                  onPressed: () {},
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
