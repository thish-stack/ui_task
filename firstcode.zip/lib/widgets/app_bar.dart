import 'package:flutter/material.dart';

PreferredSizeWidget buildAppBar() {
  return AppBar(
    title: const Text('Dashboard'),
    centerTitle: true,
  );
}

