import 'package:flutter/material.dart';
import '../widgets/app_bar.dart';
import '../widgets/bottom_nav_bar.dart';
import '../widgets/main_card.dart';
import '../widgets/stats_card.dart';
import '../widgets/tab_bar.dart';
import '../widgets/search_filter_row.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: buildAppBar(),
      bottomNavigationBar: buildBottomNavBar(),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 20),
          const SearchFilterRow(),
          const SizedBox(height: 10),
          const TabBarSection(),
          const SizedBox(height: 20),
          Expanded(
            child: SingleChildScrollView(
              child: Column(
                children: const [
                  MainCard(),
                  SizedBox(height: 10),
                  StatsCard(),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
