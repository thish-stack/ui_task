import 'package:flutter/material.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark(),
      home: const DashboardScreen(),
    );
  }
}

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: const PreferredSize(
        preferredSize: Size.fromHeight(90), // Custom height
        child: CustomAppBar(),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Column(
          children: [
            // Search and Filter Row
            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                IconButton(
                  icon: const Icon(Icons.search, size: 28),
                  onPressed: () {},
                ),
                Row(
                  children: [
                    IconButton(
                        icon: const Icon(Icons.more_horiz, size: 28),
                        onPressed: () {}),
                    IconButton(
                        icon: const Icon(Icons.calendar_today, size: 28),
                        onPressed: () {}),
                    IconButton(
                        icon: const Icon(Icons.folder, size: 28),
                        onPressed: () {}),
                    Container(
                      decoration: const BoxDecoration(
                        color: Color(0xFFE2D291),
                        shape: BoxShape.circle,
                      ),
                      // padding: const EdgeInsets.all(1),
                      child: IconButton(
                        icon: const Icon(
                          Icons.add,
                          size: 28,
                          color: Colors.black,
                        ),
                        padding: EdgeInsets.zero,
                        onPressed: () {},
                      ),
                    ),
                  ],
                ),
              ],
            ),

            const SizedBox(height: 20),
            // Tab Bar
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  _buildTabButton('Overview', 1, true),
                  _buildTabButton('PPC', 2, false),
                  _buildTabButton('Year to Year', 3, false),
                  _buildTabButton('More', 4, false),
                ],
              ),
            ),

            const SizedBox(height: 30),
            // Flexible Sections
            const Expanded(
              child: Column(
                children: [
                  // Main Card Section
                  Expanded(flex: 2, child: MainCard()),
                  SizedBox(height: 40),
                  // Stats Section with Horizontal Scroll
                  Expanded(
                    flex: 1,
                    child: SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: Row(
                        children: [
                          StatsCard(
                            title: 'Orders Created',
                            dateRange: 'Oct 16 / 21 - Nov 14 / 21',
                            amount: '\$134,970',
                            change: '+12.98%',
                          ),
                          StatsCard(
                            title: 'Total Sales',
                            dateRange: 'Oct 16 / 21 - Nov 14 / 21',
                            amount: '\$2,145,132.80',
                          ),
                          StatsCard(
                            title: 'Revenue Growth',
                            dateRange: 'Oct 16 / 21 - Nov 14 / 21',
                            amount: '\$789,312.50',
                            change: '+8.24%',
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
      bottomNavigationBar: const CustomBottomNavBar(),
    );
  }

// Widget _buildTabButton(String text, int index, bool isActive) {
//   return Row(
//     children: [
//       Container(
//         padding: const EdgeInsets.all(6),
//         decoration: BoxDecoration(
//           color: isActive ? Colors.white : Colors.white24, // Highlighted circle
//           shape: BoxShape.circle,
//         ),
//         child: Text(
//           index.toString().padLeft(2, '0'), // Display "01", "02", etc.
//           style: TextStyle(
//             fontSize: 12,
//             fontWeight: FontWeight.bold,
//             color: isActive ? Colors.black : Colors.white,
//           ),
//         ),
//       ),
//       const SizedBox(width: 6), // Space between circle and text
//       Text(
//         text,
//         style: TextStyle(
//           color: isActive ? Colors.white : Colors.white54,
//           fontWeight: FontWeight.bold,
//         ),
//       ),
//     ],
//   );
// }

  Widget _buildTabButton(String text, int index, bool isActive) {
    return Padding(
      padding:
          const EdgeInsets.symmetric(horizontal: 10), // Spacing between items
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(
                  color: Colors.white54, width: 1.5), // Circle outline
            ),
            child: Text(
              index.toString().padLeft(2, '0'), // "01", "02", etc.
              style: const TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.bold,
                color: Colors.white54,
              ),
            ),
          ),
          const SizedBox(width: 8), // Space between circle and text
          Text(
            text,
            style: TextStyle(
              color: isActive ? Colors.white : Colors.white54,
              fontWeight: FontWeight.bold,
              fontSize: 17,
            ),
          ),
        ],
      ),
    );
  }
}

// Main Card Widget
class MainCard extends StatelessWidget {
  const MainCard({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: const Color(0xFFB0D2C2),
        borderRadius: BorderRadius.circular(30),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          // Title row with spacing
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                'Top 5 products by spend',
                style: TextStyle(
                  fontSize: 23,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
              ),
              IconButton(
                icon: const Icon(Icons.more_horiz, color: Colors.black),
                onPressed: () {},
              ),
            ],
          ),
          const SizedBox(height: 10),

          // "Total Score" in center
          const Text(
            'Total score',
            style: TextStyle(fontSize: 14, color: Colors.black54),
          ),
          const SizedBox(height: 5),

          // Large number in center
          const Text(
            '2,985',
            style: TextStyle(
              fontSize: 45,
              fontWeight: FontWeight.bold,
              color: Colors.black,
            ),
          ),
          const SizedBox(height: 75),

          // Value inside a rounded box
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.5), // Transparent white
              borderRadius: BorderRadius.circular(20),
            ),
            child: const Column(
              children: [
                Text(
                  '\$1,815.67',
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    color: Colors.black,
                  ),
                ),
                SizedBox(height: 2), // Small gap
                Text(
                  'B07MCGRV7M',
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                    color: Colors.black54,
                  ),
                ),
              ],
            ),
          )
        ],
      ),
    );
  }
}

// Stats Card Widget
class StatsCard extends StatelessWidget {
  final String title;
  final String dateRange;
  final String amount;
  final String? change;

  const StatsCard({
    super.key,
    required this.title,
    required this.dateRange,
    required this.amount,
    this.change,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 230,
      margin: const EdgeInsets.symmetric(horizontal: 8),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.grey[900],
        borderRadius: BorderRadius.circular(30),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 5),
          Text(dateRange,
              style: const TextStyle(fontSize: 12, color: Colors.grey)),
          const SizedBox(height: 10),
          Text(amount,
              style:
                  const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          if (change != null)
            Text(change!,
                style: TextStyle(
                    color: change!.contains('-') ? Colors.red : Colors.green)),
        ],
      ),
    );
  }
}

class CustomAppBar extends StatelessWidget {
  const CustomAppBar({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding:
          const EdgeInsets.only(top: 50, left: 16, right: 16), // Top spacing
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween, // Equal spacing
        crossAxisAlignment: CrossAxisAlignment.center, // Align items vertically
        children: [
          // Left: More (Horiz) Icon
          IconButton(
            icon: const Icon(Icons.more_horiz, size: 28),
            onPressed: () {},
          ),

          // Center: Dashboard Text
          const Text(
            'Dashboard',
            style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold),
          ),

          // Right: Profile with Notification Badge
          Stack(
            clipBehavior: Clip.none, // Allows the badge to overflow
            children: [
              CircleAvatar(
                backgroundColor: Colors.grey[800],
                radius: 23,
                child: IconButton(
                  icon: const Icon(LucideIcons.user, size: 22),
                  onPressed: () {},
                ),
              ),
              Positioned(
                left: -5, // Adjust position
                top: 3, // Slightly move it above the icon
                child: Container(
                  padding: const EdgeInsets.all(4),
                  decoration: const BoxDecoration(
                    color: Colors.red,
                    shape: BoxShape.circle,
                  ),
                  child: const Text(
                    '9', // Badge number
                    style: TextStyle(
                      fontSize: 15,
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class CustomBottomNavBar extends StatefulWidget {
  const CustomBottomNavBar({super.key});

  @override
  _CustomBottomNavBarState createState() => _CustomBottomNavBarState();
}

class _CustomBottomNavBarState extends State<CustomBottomNavBar> {
  int _selectedIndex = 0;

  @override
  Widget build(BuildContext context) {
    return BottomNavigationBar(
      backgroundColor: Colors.black,
      unselectedItemColor: Colors.white54,
      selectedItemColor: Colors.black, // Icon color inside selected circle
      type: BottomNavigationBarType.fixed,
      showSelectedLabels: false,
      showUnselectedLabels: false,
      items: [
        _buildNavItem(Icons.dashboard_outlined, 0),
        _buildNavItem(Icons.archive_outlined, 1),
        _buildNavItem(Icons.folder_outlined, 2),
        _buildNavItem(Icons.delete_outline, 3),
        _buildNavItem(Icons.more_horiz, 4),
      ],
      currentIndex: _selectedIndex,
      onTap: (index) {
        setState(() {
          _selectedIndex = index;
        });
      },
    );
  }

  BottomNavigationBarItem _buildNavItem(IconData icon, int index) {
    bool isSelected = _selectedIndex == index;

    return BottomNavigationBarItem(
      icon: Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: isSelected ? const Color(0xFFE2D291) : Colors.transparent,
        ),
        child: Icon(
          icon,
          color: isSelected ? Colors.black : Colors.white54,
        ),
      ),
      label: '',
    );
  }
}



 
// class NavItem extends StatelessWidget {
//   final IconData icon;
//   final int index;
//   final int selectedIndex;

//   const NavItem({
//     Key? key,
//     required this.icon,
//     required this.index,
//     required this.selectedIndex,
//   }) : super(key: key);

//   @override
//   Widget build(BuildContext context) {
//     bool isSelected = selectedIndex == index;
//     return BottomNavigationBarItem(
//       icon: Container(
//         padding: const EdgeInsets.all(10),
//         decoration: BoxDecoration(
//           shape:
// BoxShape.circle,
//           color: isSelected ? const Color(0xFFE2D291) : Colors.transparent,
//         ),
//         child: Icon(
//           icon,
//           color: isSelected ? Colors.black : Colors.white54,
//         ),
//       ),
//     );
//   }
// }
      
  